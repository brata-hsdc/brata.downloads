/**
 * 
 */
package com.harris.challenge.brata.framework;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;

/**
 * Broadcast receiver to intercept SMS messages before they are passed on to
 * the default SMS app on the device.
 * 
 * @author Harris Corporation
 *
 */
public class ClueReceiver extends BroadcastReceiver{

	@Override
	public void onReceive(Context context, Intent intent) {
		// TODO Auto-generated method stub
		
	}
	
}
