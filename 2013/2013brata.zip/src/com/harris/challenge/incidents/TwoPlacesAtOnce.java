package com.harris.challenge.incidents;

import android.app.Activity;

public class TwoPlacesAtOnce extends Activity {

}
